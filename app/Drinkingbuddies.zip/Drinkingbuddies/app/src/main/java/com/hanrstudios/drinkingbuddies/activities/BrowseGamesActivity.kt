package com.hanrstudios.drinkingbuddies.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.hanrstudios.drinkingbuddies.R
import com.hanrstudios.drinkingbuddies.classes.DrinkingGame
import com.hanrstudios.drinkingbuddies.classes.User
import com.squareup.picasso.Picasso
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.Item
import com.xwray.groupie.ViewHolder
import kotlinx.android.synthetic.main.activity_browse_games.*
import kotlinx.android.synthetic.main.game_row.view.*

class BrowseGamesActivity : AppCompatActivity() {

//    companion object {
//        var currentUser: User? = null
//    }

    companion object {
        val GAME_KEY = "GAME_KEY"
    }

    val adapter = GroupAdapter<ViewHolder>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browse_games)

        verifyUserIsLoggedIn()

        fetchCurrentUser()

        fetchGames()
        getGames()

        gameoftheday_gamebrowser.setOnClickListener {
            gameOfTheDay()
        }
    }

    private fun gameOfTheDay() {
        val intent = Intent(this, GameViewerActivity::class.java)
        startActivity(intent)
    }

    private fun fetchCurrentUser() {
        var currentUser: User?
        val uid = FirebaseAuth.getInstance().uid
        val ref = FirebaseDatabase.getInstance().getReference("/users/$uid")
        ref.addListenerForSingleValueEvent(object: ValueEventListener {
            override fun onDataChange(p0: DataSnapshot) {
                currentUser = p0.getValue(User::class.java)
                Log.d("LatestMessages", "Current user is: ${currentUser?.username}")
            }
            override fun onCancelled(p0: DatabaseError) {

            }
        })
    }

    private fun verifyUserIsLoggedIn() {
        val uid = FirebaseAuth.getInstance().uid
        val intent = Intent(this, RegisterActivity::class.java)
        if (uid == null) {
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK.or(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
    }

    //creating dummy game info to show up in the recycler view

    class DumbGame: Item<ViewHolder>() {

        override fun bind(viewHolder: ViewHolder, position: Int) {

        }

        override fun getLayout(): Int {
            return R.layout.game_row
        }
    }

    private fun getGames() {

        adapter.add(DumbGame())
        adapter.add(DumbGame())
        adapter.add(DumbGame())

        recyclerview_browsegames.adapter = adapter
    }

    private fun fetchGames() {
//        val adapter = GroupAdapter<ViewHolder>()
//        recyclerview_browsegames.adapter = adapter
//
//        val ref = FirebaseDatabase.getInstance().getReference("/games")
//        ref.addListenerForSingleValueEvent(object: ValueEventListener {
//            override fun onDataChange(p0: DataSnapshot) {
//
//                p0.children.forEach {
//                    Log.d("NewGame", it.toString())
//                    val game = it.getValue(DrinkingGame::class.java)
//
//                    if (game != null) {
//                        adapter.add(GameItem(game))
//                    }
//                }
//
//                adapter.setOnItemClickListener { item, view ->
//
//                    val gameItem = item as GameItem
//
//                    val intent = Intent(view.context, GameViewerActivity::class.java)
//                    intent.putExtra(GAME_KEY, gameItem.game)
//                    startActivity(intent)
//                }
//
//            }
//
//            override fun onCancelled(p0: DatabaseError) {
//            }
//        })
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId) {
            R.id.menu_sign_out -> {
                FirebaseAuth.getInstance().signOut()
                val intent = Intent(this, RegisterActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK.or(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            }
            R.id.menu_create_game -> {
                val intent = Intent(this, GameDesignActivity::class.java)
                startActivity(intent)
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.nav_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }
}

class GameItem(val game: DrinkingGame): Item<ViewHolder>() {

    override fun bind(viewHolder: ViewHolder, position: Int) {
        //will be called in our user layout
        viewHolder.itemView.gametitle_gamerow.text = game.title
        viewHolder.itemView.author_gamerow.text = game.author
        viewHolder.itemView.category_gamerow.text = game.category
        viewHolder.itemView.createddate_gamerow.text = game.created.toString()
    }

    override fun getLayout(): Int {
        return R.layout.game_row
    }
}
