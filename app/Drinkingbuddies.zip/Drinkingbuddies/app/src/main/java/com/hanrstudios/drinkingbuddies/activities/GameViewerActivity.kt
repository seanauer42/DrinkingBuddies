package com.hanrstudios.drinkingbuddies.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.hanrstudios.drinkingbuddies.R
import com.hanrstudios.drinkingbuddies.classes.DrinkingGame
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.ViewHolder
import kotlinx.android.synthetic.main.activity_game_viewer.*

class GameViewerActivity : AppCompatActivity() {

    var currentGame: DrinkingGame? = null

    val adapter = GroupAdapter<ViewHolder>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_viewer)

        currentGame = intent.getParcelableExtra(GameDesignActivity.GAME_KEY)
        if(currentGame == null) {
            setGameAsGameOfTheDay()
        }

    }

    private fun setGameAsGameOfTheDay() {
        val ref = FirebaseDatabase.getInstance().getReference("/games/-LujoKt5xDtfLwbYUTIP").push()
        val author = ref.child("author").toString()
        val title = ref.child("title").toString()
        val private = ref.child("private").toString().toBoolean()
        val category = ref.child("category").toString()
        val rules = ref.child("rules").toString()
//        val created = ref.child("created").toString().toLong()

//        currentGame = DrinkingGame(author, title, private, category, rules, created)

        game_name_viewer.text = title
        author_gameviewer.text = author
        gamerules_gameviewer.text = rules
        posteddate_gameviewer.text = "today"

    }



//    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        when(item.itemId) {
//            R.id.menu_go_to_menu -> {
//                val intent = Intent(this, BrowseGamesActivity::class.java)
//                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK.or(Intent.FLAG_ACTIVITY_NEW_TASK)
//                startActivity(intent)
//            }
//        }
//        return super.onOptionsItemSelected(item)
//    }
//
//    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
//        menuInflater.inflate(R.menu.nav_menu, menu)
//        return super.onCreateOptionsMenu(menu)
//    }
}
