package com.hanrstudios.drinkingbuddies.classes

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize
import java.security.Timestamp

@Parcelize
class DrinkingGame(val author: String, val title: String, val private: Boolean, val category: String, val rules: String, val created: Long) :
    Parcelable {
    constructor() : this ("", "", false, "", "", -1)
}